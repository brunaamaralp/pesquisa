#!/bin/bash
# Script para iniciar o servidor backend em ambiente de produção
cd "$(dirname "$0")"
npm start
